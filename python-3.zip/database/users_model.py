class User:
    def __init__(self, id, login):
        self.id = id
        self.login = login